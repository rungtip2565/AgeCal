# Age-and-employment-period-calculation-program
Age and employment period calculation program  โปรแกรมคำนวณอายุและอายุงาน
